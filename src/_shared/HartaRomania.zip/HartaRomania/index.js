import HartaRomania from './HartaRomania';

export default HartaRomania;
